"""User-run one-shot verification. No dotenv/env lookup, key argument or key file."""
from __future__ import annotations
import getpass
import logging
import sys
import warnings

from openai import APIConnectionError, APITimeoutError, APIStatusError
from organize import Config, DEFAULT_ENDPOINT, DEFAULT_MODEL, OUTPUT_TOKEN_LIMIT, InputProblem, make_client, request_text

PUBLIC_TEXT = "周五前整理演示稿。小林负责界面截图，小周补接口说明。\n客户是否参加下周演示还没确认，演示时间也没有定。"


def main() -> int:
    # Reject pipes and tools without a real local terminal before asking for secrets.
    if not sys.stdin.isatty() or not sys.stderr.isatty():
        print("请在自己的交互式终端直接运行；本入口不接受管道或非终端密钥输入。", file=sys.stderr)
        return 2
    logging.disable(logging.CRITICAL)
    print("单次验证：不会读取 .env、环境变量或其他脚本中的密钥。")
    print("唯一目标："+DEFAULT_ENDPOINT.rstrip("/")+"/chat/completions")
    print("模型："+DEFAULT_MODEL)
    print(f"输出 Token 预算：{OUTPUT_TOKEN_LIMIT}（接口参数 max_tokens）")
    print("关闭思考模式；20 秒超时参数；最多一次应用请求；自动重试为 0；不跟随重定向。")
    print("公开教学样例（全部将发送）：\n"+PUBLIC_TEXT)
    print("可能产生少量 DeepSeek 官方 API 费用；未通过也可能已计费。")
    try:
        if input("仅授权这一次请求，请输入 YES；其他输入取消：").strip() != "YES":
            print("已取消，未读取密钥，未发请求。")
            return 0
        with warnings.catch_warnings():
            warnings.simplefilter("error", getpass.GetPassWarning)
            key = getpass.getpass("请输入本次 DeepSeek 官方专用实验 API Key（不要输入阿里云 Key；不回显、不落盘）：").strip()
        if not key or key in {"sk-xxxx", "sk-xxx", "replace_with_your_key"}:
            print("未提供真实实验密钥，未发请求。", file=sys.stderr)
            return 2
        # Key is held only by this short-lived process; no file writes or log dumps.
        with make_client(Config(key, DEFAULT_MODEL)) as client:
            answer = request_text(client, DEFAULT_MODEL, PUBLIC_TEXT)
        del key
        print("模型真实返回文本：\n"+answer)
        print("请人工核对周五截止、负责人，以及参会和时间仍未确定；本次不会自动落盘。")
        return 0
    except (EOFError, KeyboardInterrupt):
        print("已停止；若请求已经发出，服务端可能仍计费。", file=sys.stderr)
        return 130
    except getpass.GetPassWarning:
        print("无法保证不回显，已停止且未发请求。请使用本机交互式终端。", file=sys.stderr)
        return 2
    except InputProblem as exc:
        print("本次未完成："+str(exc), file=sys.stderr)
        return 2
    except APITimeoutError:
        print("请求超时；未自动重试，服务端是否收到请求需另查。", file=sys.stderr)
        return 3
    except APIConnectionError:
        print("网络连接失败；未自动重试。", file=sys.stderr)
        return 3
    except APIStatusError as exc:
        print(f"服务返回 HTTP {exc.status_code}；不打印原始错误或鉴权信息，未自动重试。", file=sys.stderr)
        return 4

if __name__ == "__main__":
    raise SystemExit(main())
