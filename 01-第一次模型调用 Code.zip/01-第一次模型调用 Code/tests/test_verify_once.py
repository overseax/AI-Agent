"""No live request: one-shot user-entry safety and request count tests."""
import contextlib
import io
import tempfile
import unittest
from unittest.mock import patch
import verify_once as once

class VerifyOnceTests(unittest.TestCase):
    def run_once(self, tty, confirm="NO", key="unused", answer="[offline fixture]"):
        out,err=io.StringIO(),io.StringIO()
        @contextlib.contextmanager
        def client(config):
            yield object()
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err), \
             patch.object(once.sys.stdin,"isatty",return_value=tty), \
             patch.object(err,"isatty",return_value=tty), \
             patch("builtins.input",return_value=confirm), \
             patch.object(once.getpass,"getpass",return_value=key) as gp, \
             patch.object(once,"make_client",side_effect=client) as mc, \
             patch.object(once,"request_text",return_value=answer) as req:
            code=once.main()
            return code,out.getvalue(),err.getvalue(),gp.call_count,mc.call_count,req.call_count

    def test_non_tty_refuses_before_key_or_request(self):
        code,out,err,gp,mc,req=self.run_once(False)
        self.assertEqual((code,gp,mc,req),(2,0,0,0))

    def test_cancel_does_not_read_key_or_request(self):
        code,out,err,gp,mc,req=self.run_once(True)
        self.assertEqual((code,gp,mc,req),(0,0,0,0))

    def test_placeholder_does_not_request(self):
        code,out,err,gp,mc,req=self.run_once(True,"YES","sk-xxxx")
        self.assertEqual((code,gp,mc,req),(2,1,0,0))

    def test_authorized_path_requests_exactly_once_without_writing(self):
        with patch("builtins.open",side_effect=AssertionError("must not write key")):
            code,out,err,gp,mc,req=self.run_once(True,"YES","offline-fake-key-not-a-secret")
        self.assertEqual((code,gp,mc,req),(0,1,1,1))
        self.assertNotIn("offline-fake-key",out+err)
        self.assertIn(once.DEFAULT_ENDPOINT.rstrip("/")+"/chat/completions",out)
        self.assertIn(once.PUBLIC_TEXT,out)
        self.assertIn("1000",out)
