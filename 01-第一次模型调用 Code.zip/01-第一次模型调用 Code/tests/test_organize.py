"""Offline contract tests. All model payloads below are test fixtures, not real output."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

import httpx2
from openai import OpenAI
import organize as app

FIXTURE_TEXT = "[离线测试夹具；非模型生成]"

class OrganizeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "samples").mkdir()
        (self.root / "samples/meeting.txt").write_text("周五交稿，时间待定。", encoding="utf-8")
        (self.root / ".env").write_text("DEEPSEEK_API_KEY=offline-test-key-not-a-secret\nMODEL=deepseek-flash\n")
        self.calls = []

    def tearDown(self):
        self.tmp.cleanup()

    def factory(self, handler):
        def build(config):
            # Real SDK + in-process transport. No socket, DNS or billable call.
            return OpenAI(api_key=config.key, base_url="https://offline.invalid/",
                          max_retries=0, timeout=20,
                          http_client=httpx2.Client(transport=httpx2.MockTransport(handler), trust_env=False))
        return build

    def invoke(self, args, handler=None):
        out, err = io.StringIO(), io.StringIO()
        def forbidden(config):
            self.fail("this case must not construct a network client")
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = app.main(args, root=self.root, client_factory=self.factory(handler) if handler else forbidden)
        return code, out.getvalue(), err.getvalue()

    def success(self, request):
        body = json.loads(request.content)
        self.calls.append(body)
        self.assertEqual(request.url.path, "/chat/completions")
        self.assertEqual(body["model"], app.DEFAULT_MODEL)
        self.assertEqual(body["messages"], [{"role":"system", "content":app.INSTRUCTIONS}, {"role":"user", "content":"周五交稿，时间待定。"}])
        self.assertEqual(body["max_tokens"], 1000)
        self.assertEqual(body["thinking"], {"type":"disabled"})
        self.assertNotIn("enable_thinking", body)
        self.assertNotIn("max_completion_tokens", body)
        self.assertFalse(body["stream"])
        self.assertNotIn("store", body)
        self.assertNotIn("max_output_tokens", body)
        self.assertNotIn("tools", body)
        return httpx2.Response(200, json={
            "id": "chatcmpl_offline_fixture", "object": "chat.completion", "created": 0,
            "model": app.DEFAULT_MODEL,
            "choices": [{"index":0, "finish_reason":"stop", "message":{"role":"assistant", "content":FIXTURE_TEXT}}],
            "usage":{"prompt_tokens":10,"completion_tokens":5,"total_tokens":15},
        })

    def test_normal_input_sdk_contract(self):
        code, out, err = self.invoke(["--file", "samples/meeting.txt", "--live"], self.success)
        self.assertEqual((code, out.strip(), err), (0, FIXTURE_TEXT, ""))
        self.assertEqual(len(self.calls), 1)

    def test_preview_without_key_or_network(self):
        (self.root / ".env").unlink()
        code, out, err = self.invoke(["--text", "待整理文本"])
        self.assertEqual(code, 0)
        self.assertIsNone(json.loads(out)["model_response"])
        self.assertFalse(json.loads(out)["network"])

    def test_missing_key(self):
        (self.root / ".env").unlink()
        code, out, err = self.invoke(["--text", "待整理文本", "--live"])
        self.assertEqual(code, 2)
        self.assertIn("缺少密钥", err)
        self.assertEqual(out, "")

    def test_network_failure_no_retry(self):
        attempts = []
        def fail(request):
            attempts.append(1)
            raise httpx2.ConnectError("offline injected connection failure", request=request)
        code, out, err = self.invoke(["--text", "待整理文本", "--live"], fail)
        self.assertEqual(code, 3)
        self.assertIn("网络连接失败", err)
        self.assertEqual((out, len(attempts)), ("", 1))

    def test_timeout(self):
        def fail(request):
            raise httpx2.ReadTimeout("offline injected timeout", request=request)
        code, out, err = self.invoke(["--text", "待整理文本", "--live"], fail)
        self.assertEqual(code, 3)
        self.assertIn("请求超时", err)

    def test_http_401_and_429(self):
        for status, message in [(401,"认证失败"),(429,"429")]:
            with self.subTest(status=status):
                def fail(request):
                    return httpx2.Response(status, json={"error":{"message":"offline fixture","type":"test"}})
                code, out, err = self.invoke(["--text", "待整理文本", "--live"], fail)
                self.assertEqual(code, 4)
                self.assertIn(message, err)
                self.assertEqual(out, "")
                self.assertNotIn("offline-test-key", err)

    def test_empty_input(self):
        code, out, err = self.invoke(["--text", "  "])
        self.assertEqual(code, 2)
        self.assertIn("不能为空", err)

    def test_oversize_input(self):
        code, out, err = self.invoke(["--text", "字" * 6001])
        self.assertEqual(code, 2)
        self.assertIn("6000", err)

    def test_outside_samples_and_symlink(self):
        (self.root / "secret.txt").write_text("not a real secret")
        (self.root / "samples/link.txt").symlink_to(self.root / "secret.txt")
        for name in ["secret.txt", "samples/../secret.txt", "samples/link.txt"]:
            code, out, err = self.invoke(["--file", name])
            self.assertEqual(code, 2)
            self.assertEqual(out, "")

    def test_empty_or_incomplete_response(self):
        for finish, content in [("stop", ""), ("length", "partial"), ("content_filter", None)]:
            def empty(request):
                return httpx2.Response(200, json={"id":"chatcmpl_fixture", "object":"chat.completion", "created":0,
                    "model":app.DEFAULT_MODEL, "choices":[{"index":0,"finish_reason":finish,
                    "message":{"role":"assistant","content":content}}]})
            code, out, err = self.invoke(["--text", "待整理文本", "--live"], empty)
            self.assertEqual(code, 2)
            self.assertEqual(out, "")

    def test_endpoint_and_model_are_not_silently_replaced(self):
        for cfg in ["ENDPOINT=https://example.invalid/v1", "MODEL=another-model"]:
            (self.root / ".env").write_text("DEEPSEEK_API_KEY=offline-test-key-not-a-secret\n"+cfg+"\n")
            code, out, err = self.invoke(["--text","待整理文本","--live"])
            self.assertEqual(code, 2)
            self.assertEqual(out, "")

    def test_client_targets_only_user_endpoint(self):
        client = app.make_client(app.Config("offline-test-key-not-a-secret", app.DEFAULT_MODEL))
        try:
            self.assertEqual(str(client.base_url), app.DEFAULT_ENDPOINT.rstrip("/")+"/")
            self.assertEqual(client.max_retries,0)
            self.assertFalse(client._client.follow_redirects)
        finally:
            client.close()

    def test_dashscope_key_is_never_reused(self):
        (self.root / ".env").write_text("DASHSCOPE_API_KEY=offline-old-service-fixture\n")
        code, out, err = self.invoke(["--text", "待整理文本", "--live"])
        self.assertEqual(code, 2)
        self.assertEqual(out, "")
        self.assertIn("不复用阿里云", err)
        self.assertNotIn("offline-old-service-fixture", err)

if __name__ == "__main__":
    unittest.main(verbosity=2)
