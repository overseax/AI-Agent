# 第 01 篇代码：命令行文本整理工具

版本：ep-01 / deepseek-chat / 2026-10-25。状态：原 17 项离线检查通过；已完成一次获准公开样例的真实模型请求及内容核对。此程序是单次文本请求应用，尚非 Agent。

## 本次固定目标

- ENDPOINT：`https://api.deepseek.com/`
- 实际请求地址：`https://api.deepseek.com/chat/completions`
- MODEL：`deepseek-flash`
- 客户端：OpenAI Python SDK 3.37.0；服务提供方：DeepSeek 官方。

DeepSeek 官方首次调用文档和 Chat API 参考已明确列出精确模型名 `deepseek-flash` 及基础地址。本篇保持用户指定配置，不更换模型或追加 /v1。需要本次获准使用的 DeepSeek 官方专用 API Key、模型权限和预算。旧阿里云 Key 不会迁移或回退使用；发现旧 DASHSCOPE_API_KEY 配置项会拒绝。

本次实测系统：Intel Mac、macOS 26.6、Python 3.12.13；python-dotenv 1.2.4、httpx2 2.16.0。Windows/Linux 未复跑。已查证公开官方文档、安装依赖并执行离线测试；2026-10-25 又完成一次获准公开样例请求。仅在进程内读取用户明确指定的私有配置，没有读取其他对话或项目的密钥。

## 文件

`organize.py` 为可复用文本整理入口，默认离线预览；`verify_once.py` 是用户在自己终端运行的安全单次验证入口。`requirements.in` 与 `requirements.lock` 固定直接和间接依赖，锁文件含安装 SHA256；`.env.example` 与 `.gitignore` 提供可复用配置模板与忽略规则；交付包不含真实 `.env`。`samples/meeting.txt` 为虚构教学便笺。`tests/` 共 17 个测试方法，无真实模型请求；`evidence/` 保存本轮实际记录。

## 安装与离线预览

在此 `code/` 目录执行，使用系统中已确认的 Python 3.12：

```bash
python3 --version
python3 -m venv .venv
source .venv/bin/activate
python --version
python -m pip install --require-hashes -r requirements.lock
python -m pip check
python organize.py --file samples/meeting.txt
```

预期 pip check 显示 `No broken requirements found.`。预览输出如下，退出码 0；它不是模型回答：

```json
{
  "mode": "preview",
  "input_chars": 51,
  "network": false,
  "model_response": null,
  "note": "仅检查输入；加 --live 才发送请求，可能计费。"
}
```

## 首次验证：用户本地输入，不落盘

本篇已有一次获准的真实验证记录，见下方证据。读者若决定在自己的账号再次验证公开样例，可在自己的交互式终端直接运行；这将是一次新的、可能计费的请求：

```bash
cd '/Users/dayphosphor/Desktop/agent/01-第一次模型调用/code'
.venv/bin/python verify_once.py
```

若尚未安装，请先按上节创建 `.venv` 并装依赖。不要把密钥放在命令行参数、环境变量赋值、聊天或截图中。

入口会显示唯一 HTTPS 目标、精确模型、完整公开教学样例、输出 Token 预算与费用提醒。输入 `YES` 才继续询问密钥；`getpass` 不回显，真实密钥只进入短期进程内存，不写 `.env`、shell 历史或日志，也不读取其他脚本和系统环境里的密钥。不支持安全不回显输入的非终端环境直接退出。

固定样例：

```text
周五前整理演示稿。小林负责界面截图，小周补接口说明。
客户是否参加下周演示还没确认，演示时间也没有定。
```

请求配置：`max_tokens=1000`，显式 `thinking.type=disabled`，非流式，20 秒超时参数，SDK 自动重试为 0，不跟随 HTTP 重定向。DeepSeek 官方 Chat API 使用 `max_tokens`，关闭思考的扩展字段为 `thinking`。显示的 Token 预算不是固定人民币费用。网络失败或超时后服务端仍可能已计费，不自动重试。

成功时只在终端显示真实返回文本，不自动保存文件；人工核对周五截止、小林/小周任务、参会与演示时间仍未确定。不要用离线夹具替代这一项。本篇已取得一次真实返回，逐项核对通过；文章仍待编辑终审，不能把单个样例当作普遍质量结论。

## 可复用配置（本机可选）

若之后反复运行文本整理工具，可自行在本机创建配置：

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

模板字段为：

```dotenv
DEEPSEEK_API_KEY=replace_with_your_key
ENDPOINT=https://api.deepseek.com/
MODEL=deepseek-flash
```

`organize.py` 只读入口旁的这份 `.env`，禁用变量展开，不查父目录、不回退到系统或其他项目密钥。模型/endpoint 与本篇固定值不一致会拒绝，不悄悄换成另一个模型。一次性入口 `verify_once.py` 完全不读取 `.env`。

准备好自己的输入、权限与预算后，可显式加 `--live`：

```bash
python organize.py --file samples/meeting.txt --live
```

`--text '短文本'` 支持直接输入，但内容可能进入 shell 历史；`--stdin` 支持 `cat samples/meeting.txt | python organize.py --stdin`。文件只允许 `samples/` 下 UTF-8，拒绝越界路径和越界符号链接。输入上限 6000 字符、文件 24000 字节。

## Chat Completions 适配说明

当前仅使用 DeepSeek 官方 Chat Completions，服务切换需要按该服务文档改参数。请求改为 `client.chat.completions.create`：`messages` 包含 system 整理规则和 user 文本，输出预算使用 `max_tokens`，通过 `extra_body={"thinking":{"type":"disabled"}}` 发送 DeepSeek 的非思考配置。没有沿用 `input`、`instructions`、`max_output_tokens`、`store`。

返回改为检查 `choices`、`finish_reason == "stop"`、非空 `message.content`；length/content_filter/空结果均拒绝为成功。没有展示 reasoning_content，不调用工具、知识库或编排。超时值并非严格的整任务墙钟上限。

## 离线测试和原始证据

```bash
python -m unittest discover -s tests -v
shasum -a 256 -c SHA256SUMS
```

技术适配轮 17 个测试方法通过；本轮未修改运行代码、未重复运行这套测试。代码 SHA256 清单定位当前版本，README 因补充真实结果已更新指纹。测试使用真实 SDK 与进程内 MockTransport，正常返回固定为 `[离线测试夹具；非模型生成]`，没有 DNS/公网模型请求。

| 范围 | 本轮结果 |
|---|---|
| 正常输入 | Chat 请求路径、messages、精确模型、输出预算、关闭思考、无旧 Responses 字段及文本解析通过 |
| 缺密钥/默认预览 | 缺密钥建客户端前退出 2；预览不读密钥、不联网 |
| 故障 | 注入网络/超时退出 3，网络只尝试 1 次；401/429 离线 HTTP 夹具退出 4 |
| 输入/响应边界 | 空白、超长、越界路径/符号链接，空正文、length/content_filter 返回均拒绝 |
| 固定服务边界 | 不同 endpoint/模型、旧 DashScope 配置被拒绝；客户端只指向用户选定 DeepSeek HTTPS 地址，无自动重试或重定向 |
| 一次性入口 | 非终端拒绝、取消不取密钥、占位密钥拒绝、确认后仅一次请求且不落盘；均为 mock 测试 |

`evidence/offline-tests.log` 是本次回归原始记录，使用此前按锁文件建立的独立 Python 3.12.13 环境执行；`clean-tests.log` 为同次回归日志副本，不代表多次统计。安装锁与依赖未改变，`clean-install.log` 保留初始干净安装过程，旧生成路径属于历史。`cli-record.txt`、`network-injection.txt` 和 `environment.json` 为本轮更新记录。

## 报错与清理

退出码：0 为预览或返回正文完成（务必看模式）；2 为输入/配置/响应不满足要求；3 为网络或超时；4 为 HTTP 服务错误；130 为本地中断。401 要核对 DeepSeek 官方密钥、权限与 endpoint，429 查额度和限速；错误不打印原始鉴权信息。

缺密钥测试在无 `.env` 的副本完成，别为复现删除有效配置。`Ctrl+C` 结束本地等待，不保证服务端停止或免计费。重建环境前 `deactivate`，确认当前目录后删除 `.venv/` 再按锁文件安装。自己保存过输出时，清理前先检查是否有要保留的材料。

已知限制：只验证了当前账号、参数和一段公开样例；没有评估更多输入、长期稳定性、其他系统。公网故障仍只做离线注入，不宣称真实断网验收。追加模型请求需要另行明确范围，不借用生产凭证。

## 一次真实模型验证（2026-10-25）

在用户确认目标、公开样例、单次范围与费用后，执行一次 DeepSeek 官方请求；只在进程内读取用户明确指定的私有配置。未把密钥复制到本代码目录或任何记录。实际验证复用 `make_client` 与 `request_text`，外围记录器保存脱敏返回及用量；未修改运行函数或重试。

- 目标：`https://api.deepseek.com/chat/completions`；请求/返回模型均为 `deepseek-flash`。
- `max_tokens=1000`、`thinking.type=disabled`、自动重试 0、不跟随重定向；应用请求尝试 1 次。
- 实际结果：非空正文，`finish_reason=stop`；用时 1.277 秒；输入 73、输出 76、总计 149 Token。
- 内容核对：周五前截止、小林/小周分工、客户参会与演示时间未定均保留，未发现新增事实。只限这个样例。
- 原始记录：`evidence/live-result.json`；返回原文：`evidence/live-response.txt`；逐项评估：`evidence/live-review.json`；记录指纹：`evidence/live-evidence-SHA256SUMS`。

原离线日志中的“未发公网请求”指那一次离线检查，不包括后续这次获准的真实调用。公开交付不含用户私有 `.env`，也不包含鉴权头或真实密钥。
